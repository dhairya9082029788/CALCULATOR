//
//  ViewController.swift
//  UIofCalculator
//
//  Created by Dhairya on 25/05/21.
//

import UIKit

class ViewController: UIViewController {
    
   
    
    @IBOutlet weak var resultbtn: UIButton!
    @IBOutlet weak var labelLBL: UILabel!
    @IBOutlet weak var FirstNoTK: UITextField!
    @IBOutlet weak var SecondNoTF: UITextField!
    @IBOutlet weak var segment: UISegmentedControl!
    
    @IBAction func button(_ sender: Any) {
        if segment.selectedSegmentIndex == 0{
                
                let a = Double(FirstNoTK.text!)
                let b = Double(SecondNoTF.text!)
                
                let c = Double(a! + b!)
                
            labelLBL.text = "\(c)"
            labelLBL.isHidden = false
                }
                else if segment.selectedSegmentIndex == 1{
                    let a = Double(FirstNoTK.text!)
                    let b = Double(SecondNoTF.text!)
                    
                    let c = Double(a! - b!)
                    
                    labelLBL.text = "\(c)"
                    labelLBL.isHidden = false
                    
    }
                else if segment.selectedSegmentIndex == 2{
                    let a = Double(FirstNoTK.text!)
                    let b = Double(SecondNoTF.text!)
                    
                    let c = Double(a! / b!)
                    
                labelLBL.text = "\(c)"
                labelLBL.isHidden = false
                    
                }
        else if segment.selectedSegmentIndex == 2{
            let a = Double(FirstNoTK.text!)
            let b = Double(SecondNoTF.text!)
            
            let c = Double(a! * b!)
            
        labelLBL.text = "\(c)"
        labelLBL.isHidden = false
        }
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        labelLBL.isHidden = true
        resultbtn.layer.cornerRadius = 50
        SecondNoTF.layer.cornerRadius = 5
        SecondNoTF.layer.borderWidth = 2.0
        FirstNoTK.layer.cornerRadius = 5
        FirstNoTK.layer.borderWidth = 2.0
        resultbtn.layer.borderWidth = 3
        segment.layer.borderWidth = 2
       
    }

}
   

